NTM WS22
Implementing the JPEG Compression Algorithm
Michael Mente 01634435, Lukas Pezzei 11834075, Julian Saria 01608505

All of us submit the same ZIP-file with the same contents

What do we submit:
- images/ -> contains input png files we operate our algorithm on
- jpeg_implementation/ -> contains the source code of our implementation
- JPEG.html -> rendered Jupyter notebook showing the step by step process
- JPEG.ipynb -> Jupyter notebook showing the step by step process
- JPEG_Matrix_sample.html -> JPEG algorithm by means of a smaller 8x8 matrix for better mathematical understanding
- JPEG_Matrix_sample.ipynd -> JPEG algorithm by means of a smaller 8x8 matrix for better mathematical understanding
- NTM_WS22_Implementing_the_JPEG_Compression_Algorithm.pdf -> our written report/paper
- README.txt -> this file

